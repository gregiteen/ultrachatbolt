/*
  # Migration removed
  
  This migration has been consolidated into 20250212042806_tender_garden.sql
  to avoid duplicate operations and potential conflicts.
  
  The changes (foreign key constraints and indexes) are now handled in that migration.
*/

-- This file intentionally left empty as its contents have been moved
-- to 20250212042806_tender_garden.sql